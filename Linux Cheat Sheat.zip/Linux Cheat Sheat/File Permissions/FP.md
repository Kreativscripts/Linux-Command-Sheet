# File Permissions
chmod [permissions] [file] # Change file permissions
chown [owner]:[group] [file] # Change file owner and group
chgrp [group] [file]     # Change file group ownership
