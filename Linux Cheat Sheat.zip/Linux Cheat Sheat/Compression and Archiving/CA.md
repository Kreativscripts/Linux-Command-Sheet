# Compression and Archiving
tar -cvf [archive.tar] [directory] # Create a tar archive
tar -xvf [archive.tar]             # Extract a tar archive
gzip [file]                        # Compress a file with gzip
gunzip [file.gz]                   # Decompress a gzip file
zip [archive.zip] [file]           # Create a zip archive
unzip [archive.zip]                # Extract a zip archive
