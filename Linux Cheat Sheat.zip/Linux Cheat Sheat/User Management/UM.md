# User Management
sudo adduser [username]   # Add a new user
sudo passwd [username]    # Change user password
sudo deluser [username]   # Remove a user
sudo usermod -aG [group] [username] # Add user to a group
groups [username]         # Show groups for a user
sudo usermod -G [group] [username] # Remove user from a group