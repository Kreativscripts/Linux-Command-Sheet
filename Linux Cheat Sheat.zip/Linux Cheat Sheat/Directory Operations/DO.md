# Directory Operations
pwd                      # Print the current working directory
ls                       # List directory contents
ls -l                    # List with detailed information
ls -a                    # List all files, including hidden ones
cd [directory]           # Change directory
cd ..                    # Move up one directory
cd ~                     # Navigate to the home directory
mkdir [directory]        # Create a new directory
rmdir [directory]        # Remove an empty directory
rm -r [directory]        # Remove a directory and its contents recursively
cp -r [source] [destination] # Copy directories recursively
mv [source] [destination] # Move or rename files or directories
