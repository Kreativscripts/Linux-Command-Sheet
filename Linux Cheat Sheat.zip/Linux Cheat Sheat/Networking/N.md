# Networking
ifconfig                 # Display network interfaces
ping [host]              # Send ICMP ECHO_REQUEST to network hosts
traceroute [host]        # Print the route packets take to the network host
netstat                  # Print network connections, routing tables, interface statistics, masquerade connections, and multicast memberships
ssh user@[host]          # Connect to a remote host via SSH
scp [source] [destination] # Securely copy files between hosts
hostname                 # Show or set the system's host name
