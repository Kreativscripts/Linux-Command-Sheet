# File Oprations
touch [file]             # Create a new empty file
cp [source] [destination] # Copy files
mv [source] [destination] # Move or rename files
rm [file]                # Remove a file
cat [file]               # Concatenate and display file content
head [file]              # Display the first lines of a file
tail [file]              # Display the last lines of a file
nano [file]              # Edit a file using Nano editor
vim [file]               # Edit a file using Vim editor
