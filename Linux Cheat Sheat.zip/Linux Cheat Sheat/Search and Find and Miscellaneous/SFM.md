# Search and Find
find [directory] -name [filename] # Find files and directories
grep [pattern] [file]        # Search for a pattern within a file
locate [file]                # Find files by name
which [command]              # Locate a command

# Miscellaneous
echo [text]              # Display text
date                     # Display or set the system date and time
cal                      # Display a calendar
history                  # Show command history
alias [name]='[command]' # Create an alias for a command