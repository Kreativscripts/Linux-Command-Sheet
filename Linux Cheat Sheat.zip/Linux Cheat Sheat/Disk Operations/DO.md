# Disk Operations
mount [device] [directory] # Mount a device
umount [device]           # Unmount a device
fdisk -l                  # List disk partitions
mkfs.ext4 [device]        # Format a partition with ext4 filesystem