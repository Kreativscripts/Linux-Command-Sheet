# System Information
uname -a                 # Display all system information
df -h                    # Display disk space usage
du -h [directory]        # Display directory space usage
free -h                  # Display memory usage
uptime                   # Show system uptime
who                      # Show who is logged on
env                      # Display environment variables
