# Downloading Files
wget [url]               # Download files from the web
curl -O [url]            # Download files from the web
