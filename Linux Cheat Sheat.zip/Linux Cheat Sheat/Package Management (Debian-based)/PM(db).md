# Package Management (Debian-based)
sudo apt update          # Update package lists
sudo apt upgrade         # Upgrade all packages
sudo apt install [package] # Install a package
sudo apt remove [package] # Remove a package
apt search [package]     # Search for a package
