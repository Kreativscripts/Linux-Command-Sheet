# Process Management
ps                       # Display current shell processes
ps aux                   # Display all running processes
top                      # Display running processes
htop                     # Interactive process viewer (if installed)
kill [pid]               # Kill a process by its PID
killall [process]        # Kill all processes with the given name
bg                       # Resume a suspended job in the background
fg                       # Bring a background job to the foreground
jobs                     # List current jobs